"use strict";

var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    apiai = require('apiai'),
    port = 8080;

var aiapp = apiai("c86c3972be714362961ef258e1f6345f");

var options = {
    sessionId: 'abcseeedsfaefawefas'
};


app.use(bodyParser());

app.use(express.static(__dirname + '/public'));
app.listen(port, '0.0.0.0', function () {
        console.log("server starting on port " + port);
});


// Imports the Google Cloud client library
const language = require('@google-cloud/language');

// Instantiates a client
const client = new language.LanguageServiceClient({
    projectId: '2f06d5e36eef8923bfa8b3c40807b3e61110eb48',
    keyFilename: 'Restuarant-6d93bad53e54.json',
  });

//sentiment analysis end point , accessing google cloud natural lang api
app.get('/api/sentiment',function(req,res){
    const text = req.query.text;
    const document = {
      content: text,
      type: 'PLAIN_TEXT',
    };
    // Detects the sentiment of the text
    client
      .analyzeSentiment({document: document})
      .then(results => {
        const sentiment = results[0].documentSentiment;
        res.send({
            "status":"success",
            "sentiment_value": sentiment.score
        })
      })
      .catch(err => {
        console.error('ERROR:', err);
        res.send({
            "status":"error",
            "msg": err
        })
      });
    
});

app.post('/api/bot', function(req,res){
var request = aiapp.textRequest(req.body.input.text, options);
request.on('response', function(response) {
    //console.log(response);
    return res.json(response);
});

request.on('error', function(error) {
    console.log(error);
    return res.status(error.code || 500).json(error);
});

request.end();
//response.result.fulfillment.speech
     
})