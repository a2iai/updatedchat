"use strict";

// Variables for chat and stored context specific events
var params = { // Object for parameters sent to the Watson Conversation service
    input: '',
    context: ''
};
var user_typed = false;
var last_added_message;
var last_typed_message;
var watson = 'Bot';
var user = '';
var uri = 'http://localhost:8080/api/bot';
var suggestions_clicked = false;
var negative_count = 0;
var user_name = "";
var user_image = "/img/user.jpg";
var user_email = "";
var is_current_message_negative = false;
var slightly_negative = false;
var highly_negative = false;
var context; // Very important. Holds all the data for the current point of the chat.

/**
 * @summary Enter Keyboard Event.
 *
 * When a user presses enter in the chat input window it triggers the service interactions.
 *
 * @function newEvent
 * @param {Object} e - Information about the keyboard event.
 */




function onSignIn(googleUser) {
     var profile = googleUser.getBasicProfile();
     user_name = profile.getName();
     user_image = profile.getImageUrl();
     user_email = profile.getEmail();
     document.getElementById('login_card').style.display = "none";
     document.getElementById('chat_controls').style.display = "block";
	 document.getElementById('user_avatar').style.display = "block";
	 document.getElementById('user_avatar').src = user_image;
    //  document.getElementById('show_signout').style.display = "block";
     //document.getElementById('signed_in_as').innerHTML += " <img src='"  + user_image + "' style='float:right;border-radius:55px;width:10%;height:20%;display:inline-block;position:relative'>  " +  user_name;
	//document.getElementById('header').innerHTML += " <img src='"  + user_image + "' style='float:right;border-radius:55px;width:10%;height:25%;display:inline-block;margin-top:-75px'> " ;//
}

  function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
         window.location.reload();
    });
  }
  
  
  function set_theme_color(){
	//alert("here");
	document.getElementById('header').style.background = (document.getElementById("color_changer").value);
  }

 function show_chat_bot(){
     if(document.getElementById('icon').innerHTML == "message"){
        document.getElementById('chat_bot_container').style.display = "block";
        document.getElementById('icon').innerHTML = "close";
     }
     else{
        document.getElementById('chat_bot_container').style.display = "none";
        document.getElementById('icon').innerHTML = "message";
        
     }
 }


function newEvent(e) {    
    // Only check for a return/enter press - Event 13
    if(document.getElementById('chatMessage').value != ""){
        document.getElementById('send').style.display = "block";
        document.getElementById('mic').style.display = "none";        
    }
    else if(document.getElementById('chatMessage').value == ""){
        document.getElementById('send').style.display = "none";
        document.getElementById('mic').style.display = "block";        
    }

    if (e.which === 13 || e.keyCode === 13) {
        document.getElementById('bot_response_loading').style.display = "block";                    
        document.getElementById('send').style.display = "none";
        if(suggestions_clicked){
            document.getElementById('show_suggestions').innerHTML = ""; 
            document.getElementById('show_suggestions').className = "";   
            document.getElementById('chatMessage').placeholder = "Send A Message";         
        }
        document.getElementById('mic').style.display = "block"; 
        var userInput = document.getElementById('chatMessage');
        var text = userInput.value; // Using text as a recurring variable through functions
        text = text.replace(/(\r\n|\n|\r)/gm, ""); // Remove erroneous characters
        // If there is any input then check if this is a claim step Some claim steps are
        // handled in newEvent and others are handled in userMessage
        if (text) {
            analyseSentiment(text);
			
            // Display the user's text in the chat box and null out input box
        } else {
            // Blank user message. Do nothing.
            console.error("No message.");
            userInput.value = '';
            return false;
        }
    }
}

function analyseSentiment(user_input){
    // console.log(user_input);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText, "\n Negative Statements count =  " + negative_count);
            if(JSON.parse(this.responseText).status == "success"){
                if(JSON.parse(this.responseText).sentiment_value < -0.25 && JSON.parse(this.responseText).sentiment_value >= -0.70){
                    is_current_message_negative = true;
                    slightly_negative = true;
                    highly_negative = false;
                    negative_count += 1;
                }
                else if(JSON.parse(this.responseText).sentiment_value < -0.7){
                    is_current_message_negative = true;
                    highly_negative = true;
                    slightly_negative = false;
                    negative_count += 1;
                }
            }
            //console.log(this.responseText)
            displayMessage(user_input, user);
            document.getElementById('chatMessage').value = '';
            userMessage(user_input.trim());
        }
    };
    xhttp.open("GET", " http://localhost:8080/api/sentiment?text="+user_input, true);
    xhttp.send();
}



function start_speech(){
    var recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    var output = document.getElementById('chatMessage');    
    document.getElementById('mic').style.color = "blue";
    output.placeholder = "Listening....";    
    recognition.start();

    recognition.onresult = function(event) {
      output.value = event.results[0][0].transcript;
      output.focus();
      document.getElementById('mic').style.color = "grey";
      output.placeholder = "Add a Message"; 
      document.getElementById('send').style.display = "block";
      document.getElementById('mic').style.display = "none";      
	  setTimeout(function(){
		  click_send();
	  },2000);
    };
}

function click_send() {
        document.getElementById('bot_response_loading').style.display = "block";            
        document.getElementById('send').style.display = "none";
        if(suggestions_clicked){
            document.getElementById('show_suggestions').innerHTML = ""; 
            document.getElementById('show_suggestions').className = "";   
            document.getElementById('chatMessage').placeholder = "Send A Message";         
        }
        document.getElementById('mic').style.display = "block"; 
        var userInput = document.getElementById('chatMessage');
        var text = userInput.value; // Using text as a recurring variable through functions
        text = text.replace(/(\r\n|\n|\r)/gm, ""); // Remove erroneous characters
        // If there is any input then check if this is a claim step Some claim steps are
        // handled in newEvent and others are handled in userMessage
        if (text) {
            // Display the user's text in the chat box and null out input box
            displayMessage(text, user);
            userInput.value = '';
            userMessage(text.trim());

        } else {
            // Blank user message. Do nothing.
            console.error("No message.");
            userInput.value = '';
            return false;
        }
}

/**
 * @summary Main User Interaction with Service.
 *
 * Primary function for parsing the conversation context  object.
 *
 * @function userMessage
 * @param {String} message - Input message from user or page load.
 */
function userMessage(message) {
    // Set parameters for payload to Watson Conversation
    params.input = {
        text: message // User defined text to be sent to service
    };

    // Add variables to the context as more options are chosen
    if (context) {
        params.context = context; // Add a context if there is one previously stored
        params.context.username = "Prasanna";
    }

    var xhr = new XMLHttpRequest()


    xhr.open('POST', uri, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function () {
        // Verify if there is a success code response and some text was sent
        if (xhr.status === 200 && xhr.responseText) {

            var response = JSON.parse(xhr.responseText);
            var text = response.result.fulfillment.speech;
            context = response.context; // Store the context for next round of questions

            //console.log("Got response from Bot: ", JSON.stringify(response));
            var messages = response.result.fulfillment.messages;
            var show_card = false;
            var card_object = {};
            var show_carousel = false;
            var carousel_object = [];
            var show_list = false;
            var suggestions = [];
            for (var i = 0; i < messages.length; i++) {
                if (messages[i].type == "4") {
                    if (messages[i].payload.A2I.attachmentLayout == "card") {
                        show_card = true;
                        card_object = messages[i].payload.A2I.attachments[0].content;
                    }
                    if (messages[i].payload.A2I.attachmentLayout == "carousel") {
                        show_carousel = true;
                        carousel_object = messages[i].payload.A2I.attachments[0].content;
                    }
                    if (messages[i].payload.A2I.attachmentLayout == "list") {
                        show_list = true;
                        suggestions = messages[i].payload.A2I.attachments[0].content.suggestions;
                    }
                    

                }
            }
            //alert(JSON.stringify(response.result.fulfillment.messages));

            displayMessage(text, watson);
            if (show_card) {
                displayCard(card_object);
            }
            if (show_carousel) {
                displayCorousel(carousel_object);
            }
            if(show_list){
                displayList(suggestions);
            }
            document.getElementById('bot_response_loading').style.display = "none";
            

        } else {
            console.error('Server error for Conversation. Return status of: ', xhr.statusText);
        }
    };

    xhr.onerror = function (e) {
        displayMessage('response received from apiai' + xhr.statusText, user);
        console.log('Network error trying to send message!');
    };

    //console.log(JSON.stringify(params));

    xhr.send(JSON.stringify(params));

}

/**
 * @summary Display Chat Bubble.
 *
 * Formats the chat bubble element based on if the message is from the user or from Bot.
 *
 * @function displayMessage
 * @param {String} text - Text to be dispalyed in chat box.
 * @param {String} user - Denotes if the message is from Bot or the user.
 * @return null
 */
function displayMessage(text, user) {

    var chat = document.getElementById('chatBox');
    var bubble = document.createElement('div');
    bubble.className = 'message'; // Wrap the text first in a message class for common formatting
    // Set chat bubble color and position based on the user parameter
    if (user === watson) {
        if(user_typed){
            last_added_message.childNodes[0].children[0].style.display = "none";
            bubble.innerHTML = "<div  style='textalign:center'><img src='/img/user2.png' id='bot_image' style='border-radius:55px;width:10%;height:20%;display:inline-block;position:relative'> <div class='bot'>" + text + "</div></div>";                                
        }
        else{
            bubble.innerHTML = "<div style='textalign:center'> <img src='/img/user2.png' id='bot_image' style='border-radius:55px;width:10%;height:20%;display:inline-block;position:relative'> <div class='bot'>" + "Hi " + user_name + " ,How can I help you?" + "</div></div>";                                            
        }
        last_added_message = bubble;               
    } else {
        suggestions_clicked = false;
        if(user_typed && negative_count < 2){
            last_typed_message.childNodes[0].children[0].style.display = "none";
        }
        else if(user_typed && negative_count >= 2){
            last_typed_message.childNodes[0].children[1].style.display = "none";
        }
        last_typed_message = bubble;
        user_typed = true;
        if(is_current_message_negative && slightly_negative){
            bubble.innerHTML = "<div style='textalign:center'> <span><i class='material-icons' style='border-radius:15px;margin-left:2%;background-color:#E53935' title='Oops! Its a negative sentiment statment.'> remove </i> </span> <img src='" + user_image + "' style='float:right;border-radius:55px;width:10%;height:20%;display:inline-block;position:relative;'> <div class='user'>" + text + "</div></div>";                        
        }
        else if(is_current_message_negative && highly_negative){
            bubble.innerHTML = "<div style='textalign:center'> <span><i class='material-icons' style='border-radius:15px;margin-left:2%;background-color:#B71C1C' title='Oops! Its a negative sentiment statment.'> remove </i> </span> <img src='" + user_image + "' style='float:right;border-radius:55px;width:10%;height:20%;display:inline-block;position:relative;'> <div class='user'>" + text + "</div></div>";                        
        }
        else{
            bubble.innerHTML = "<div style='textalign:center'> <img src='" + user_image + "' style='float:right;border-radius:55px;width:10%;height:20%;display:inline-block;position:relative;'> <div class='user'>" + text + "</div></div>";            
        }
        if(negative_count >=2 ){
            document.getElementById('chatMessage').disabled = true;
            document.getElementById('send').style.display = "none";
            document.getElementById('mic').style.display = "none";
            //alert("Need to change");
        }
        is_current_message_negative = false;
        // bubble.innerHTML = "<div style='textalign:center'> <div class='user'>" + text + "</div><img src='/img/user2.jpg' style='border-radius:55px;width:10%;height:20%;display:none;'></div>";
    }
    chat.appendChild(bubble);
    chat.scrollTop = chat.scrollHeight; // Move chat down to the last message displayed
    document.getElementById('chatMessage').focus();

    return null;
}

function displayCard(card_object) {
    var chat = document.getElementById('chatBox');
    var bubble = document.createElement('div');
    bubble.className = 'message'; // Wrap the text first in a message class for common formatting

    // Set chat bubble color and position based on the user parameter
   bubble.innerHTML = `<br/>
    <div class="demo-card-square mdl-card mdl-shadow--6dp" id="card_response">
        <div class="mdl-card__title mdl-card--expand" style="color:black;background:url('` + card_object.CardImage + `') no-repeat">            
        </div>
        <div class="mdl-card__supporting-text"> <h2 class="mdl-card__title-text">` + card_object.title + `</h2>` + card_object.subtitle + `<i class="price-text-color fa fa-star" style="color:gold;float:right"></i>
    <i class="price-text-color fa fa-paperclip"></i>
    </div>
        <div class="mdl-card__actions mdl-card--border" style="margin-left:5%">
            <a href="` + card_object.TwitterLink + `" target="_blank"><i class="fa fa-twitter" aria-hidden="true" style="color:blue;font-size:20px"></i></a>  
            <a href="` + card_object.TwitterLink + `" target="_blank"><i class="fa fa-facebook" aria-hidden="true" style="color:blue;margin-left:5%;font-size:20px"></i></a>
            <a href="` + card_object.TwitterLink + `" target="_blank"><i class="fa fa-linkedin" aria-hidden="true" style="color:blue;margin-left:5%;font-size:20px"></i></a> 
        </div>
  </div>
  `;/*bubble.innerHTML = `
  <div id="wrapper" class="demo-card-square mdl-card mdl-shadow--6dp" style='margin:16px'>
       <div class="wrapper-content animated fadeInRight">
       <div class="row">
       
               <div style=' background-color: #ffffff;
 border: 0px solid #e7eaec;
 border-radius:10px;
 padding: 15px;
 margin-bottom: 10px;'>
                   <a href="profile.html">
                   <div class="col-sm-4" style='margin-top:10%'>
                       <div class="text-center">
                           <img alt="image" class="img-circle m-t-xs img-responsive" src="http://ww1.prweb.com/prfiles/2012/10/03/9972951/gI_84992_Raghurama%20Kote.jpg">
                       </div>
                   </div>
                   <div class="col-sm-8">
                       <h3><strong style='color:black;font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;'>Raghuram Kote</strong></h3>
					   <div style='color:black;font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;margin-top:20px'>COO</div>
                       <div class="mdl-card__actions mdl-card--border" style="margin-left:5%">
            <a href="` + card_object.TwitterLink + `" target="_blank"><i class="fa fa-twitter" aria-hidden="true" style="color:blue;font-size:20px"></i></a>  
            <a href="` + card_object.TwitterLink + `" target="_blank"><i class="fa fa-facebook" aria-hidden="true" style="color:blue;margin-left:5%;font-size:20px"></i></a>
            <a href="` + card_object.TwitterLink + `" target="_blank"><i class="fa fa-linkedin" aria-hidden="true" style="color:blue;margin-left:5%;font-size:20px"></i></a> 
        </div>

                   </div>
                   <div class="clearfix"></div>
                       </a>
               </div>
           </div>
  `*/

    chat.appendChild(bubble);
    chat.scrollTop = chat.scrollHeight; // Move chat down to the last message displayed
    document
        .getElementById('chatMessage')
        .focus();

    return null;
}

function displayCorousel(carousel_object) {
    var chat = document.getElementById('chatBox');
    var bubble = document.createElement('div');
    bubble.className = 'message'; // Wrap the text first in a message class for common formatting

    var carousel_div = document.createElement('div');
    carousel_div.id = "myCarousel";
    carousel_div.className = "carousel slide demo-card-square mdl-card mdl-shadow--6dp";
    carousel_div.setAttribute("data-ride", "carousel");
	carousel_div.style.marginLeft = '20px';
	carousel_div.style.width = '100%';
    var inner_carousel = document.createElement('div');
    inner_carousel.className = "carousel-inner";
    var ol = document.createElement('ol');
    ol.className = "carousel-indicators";
    for (var i = 0; i < carousel_object.length; i++) {
        var div = document.createElement('div');
        var li = document.createElement('li');
        var title_div = document.createElement('div');
        var title_text = document.createTextNode(carousel_object[i].title + " for " + carousel_object[i].price);
        title_div.style.textAlign = "center";
        title_div.style.color = "black";
        title_div.style.fontSize = "20px";
        title_div.appendChild(title_text);
        if (i == 0) {
            div.className = "item active";
            li.className = "active";
        } else 
            div.className = "item";
        li.setAttribute("data-target", "myCarousel");
        li.setAttribute("data-slide-to", i + "");
        ol.appendChild(li);
        div.appendChild(title_div);
        var img = document.createElement('img');
        img.src = carousel_object[i].CardImage;
        div.appendChild(img);
        inner_carousel.appendChild(div);
    }
    var left_controls = document.createElement('a');
    left_controls.className = "left carousel-control";
    left_controls.href = "#myCarousel";
    left_controls.style.color = "black";
    left_controls.setAttribute('data-slide', 'prev');
    var span_left_controls = document.createElement('span');
    span_left_controls.className = "glyphicon glyphicon-chevron-left";
    left_controls.appendChild(span_left_controls);

    var right_controls = document.createElement('a');
    right_controls.className = "right carousel-control";
    right_controls.href = "#myCarousel";
    right_controls.setAttribute('data-slide', 'next');
    var span_right_controls = document.createElement('span');
    span_right_controls.className = "glyphicon glyphicon-chevron-right";
    right_controls.appendChild(span_right_controls);

    carousel_div.appendChild(inner_carousel);
    carousel_div.appendChild(left_controls);
    carousel_div.appendChild(right_controls);
    carousel_div.appendChild(ol);

    bubble.appendChild(carousel_div);
    chat.appendChild(bubble);
    chat.scrollTop = chat.scrollHeight; // Move chat down to the last message displayed
    document.getElementById('chatMessage').focus();

    return null;
}

function displayList(suggestions_array){
    var chat = document.getElementById('chatBox');
    var bubble = document.createElement('div');
    bubble.className = 'message';

//     <span class="mdl-chip">
//     <span class="mdl-chip__text">Basic Chip</span>
// </span>
    // todo
    var toshow_div = document.getElementById('show_suggestions');
    toshow_div.className = "suggestions";
    document.getElementById('chatMessage').placeholder = "Choose one from below";
    for(var i=0;i< suggestions_array.length;i++){
        var suggestions_chip = document.createElement('span');
        suggestions_chip.onclick = function(event){
            //displayMessage(event.target.innerHTML,"user");
            if(event.target.innerHTML[0] == "<"){
                document.getElementById('chatMessage').value = event.target.childNodes[0].innerHTML;                
            }
            else{
                document.getElementById('chatMessage').value = event.target.innerHTML;                
            }
            document.getElementById('chatMessage').focus();
            document.getElementById('send').style.display = "block";
            document.getElementById('mic').style.display = "none";  
            suggestions_clicked = true;
        }
        suggestions_chip.className = "mdl-chip";
        var inner_content = document.createElement('span');
        inner_content.className = "mdl-chip__text";
        var text_content = document.createTextNode(suggestions_array[i]);
        inner_content.appendChild(text_content);
        suggestions_chip.appendChild(inner_content);
        toshow_div.appendChild(suggestions_chip)
    }
    
    // bubble.appendChild(toshow_div);
    // chat.appendChild(bubble);
    // chat.scrollTop = chat.scrollHeight; // Move chat down to the last message displayed
    // document.getElementById('chatMessage').focus();
    return null;
}